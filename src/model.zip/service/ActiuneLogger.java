package service;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ActiuneLogger {
    private static final String FILE_NAME = "src/log.csv";
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    public static void logActiune(String actiune) {
        String timestamp = LocalDateTime.now().format(FORMAT);
        try (FileWriter fw = new FileWriter(FILE_NAME, true)) {
            fw.write("[" + timestamp + "] " + actiune + "\n");
        } catch (IOException e) {
            System.out.println("Eroare la scrierea în fișierul de log: " + e.getMessage());
        }
    }
}
