import model.*;
import service.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AplicatieService service = new AplicatieService();
        Autentificare autentificare = new Autentificare(service.utilizatorRepo);

        boolean running = true;
        while (running) {
            System.out.println("\n--- Bine ai venit ---");
            System.out.println("1. Utilizator");
            System.out.println("2. Client");
            System.out.println("0. Ieșire");
            System.out.print("Alege opțiunea: ");
            String opt = scanner.nextLine();

            switch (opt) {
                case "1" -> meniuUtilizator(scanner, service, autentificare);
                case "2" -> meniuClient(scanner, service);
                case "0" -> running = false;
                default -> System.out.println("Opțiune invalidă.");
            }
        }

        System.out.println("La revedere!");
    }

    private static void meniuUtilizator(Scanner scanner, AplicatieService service, Autentificare auth) {
        boolean active = true;
        Utilizator utilizatorLogat = null;

        while (active) {
            if (utilizatorLogat == null) {
                System.out.println("\n--- Meniu Utilizator ---");
                System.out.println("1. Autentificare");
                System.out.println("2. Creează cont");
                System.out.println("0. Înapoi");
                System.out.print("Alege opțiunea: ");
                String opt = scanner.nextLine();

                switch (opt) {
                    case "1" -> utilizatorLogat = auth.login();
                    case "2" -> {
                        auth.inregistrare();
                        utilizatorLogat = auth.login();
                    }
                    case "0" -> active = false;
                    default -> System.out.println("Opțiune invalidă.");
                }
            } else {
                System.out.println("\n--- Meniu Utilizator Autentificat ---");
                System.out.println("1. Vizualizează categorii");
                System.out.println("2. Vizualizează locații");
                System.out.println("3. Vizualizează evenimente");
                System.out.println("0. Delogare");
                System.out.print("Alege opțiunea: ");
                String opt = scanner.nextLine();

                switch (opt) {
                    case "1" -> afiseazaLista("categorii", service.categorieRepo.getCategorii());
                    case "2" -> afiseazaLista("locații", service.locatieRepo.getLocatii());
                    case "3" -> afiseazaLista("evenimente", service.evenimentRepo.getEvenimente());
                    case "0" -> {
                        utilizatorLogat = null;
                        System.out.println("Delogat cu succes.");
                    }
                    default -> System.out.println("Opțiune invalidă.");
                }
            }
        }
    }

    private static void meniuClient(Scanner scanner, AplicatieService service) {
        boolean active = true;
        Client clientLogat = null;

        while (active) {
            if (clientLogat == null) {
                System.out.println("\n--- Meniu Client ---");
                System.out.println("1. Autentificare (email + parolă)");
                System.out.println("2. Creează client nou (cu ID utilizator existent)");
                System.out.println("0. Înapoi");
                System.out.print("Alege opțiunea: ");
                String opt = scanner.nextLine();

                switch (opt) {
                    case "1" -> {
                        System.out.print("Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Parolă: ");
                        String parola = scanner.nextLine();

                        Utilizator utilizator = service.utilizatorRepo.getUtilizatori().stream()
                                .filter(u -> u.getEmail().equals(email) && u.getParola().equals(parola))
                                .findFirst().orElse(null);

                        if (utilizator == null) {
                            System.out.println("Autentificare eșuată.");
                        } else {
                            clientLogat = service.clientRepo.getClienti().stream()
                                    .filter(c -> c.getUtilizator().getId() == utilizator.getId())
                                    .findFirst().orElse(null);
                            if (clientLogat == null) {
                                System.out.println("Nu există client asociat acestui utilizator.");
                            } else {
                                System.out.println("Autentificat ca: " + clientLogat.getNume() + " " + clientLogat.getPrenume());
                            }
                        }
                    }
                    case "2" -> {
                        System.out.print("ID utilizator existent: ");
                        int uid = Integer.parseInt(scanner.nextLine());
                        Utilizator utilizator = service.utilizatorRepo.getUtilizatori().stream()
                                .filter(u -> u.getId() == uid)
                                .findFirst().orElse(null);
                        if (utilizator == null) {
                            System.out.println("ID-ul de utilizator nu există.");
                            break;
                        }
                        System.out.print("Nume: ");
                        String nume = scanner.nextLine();
                        System.out.print("Prenume: ");
                        String prenume = scanner.nextLine();
                        service.clientRepo.adaugaClient(new Client(0, utilizator, nume, prenume));
                        System.out.println("Client creat.");
                    }
                    case "0" -> active = false;
                    default -> System.out.println("Opțiune invalidă.");
                }
            } else {
                System.out.println("\n--- Meniu Client Autentificat ---");
                System.out.println("1. Adaugă categorie");
                System.out.println("2. Adaugă locație");
                System.out.println("3. Adaugă eveniment");
                System.out.println("4. Vizualizează categorii");
                System.out.println("5. Vizualizează locații");
                System.out.println("6. Vizualizează utilizatori");
                System.out.println("7. Vizualizează clienți");
                System.out.println("8. Vizualizează evenimente");
                System.out.println("9. Șterge eveniment");
                System.out.println("10. Editează eveniment");
                System.out.println("0. Delogare");
                System.out.print("Alege opțiunea: ");
                String opt = scanner.nextLine();

                switch (opt) {
                    case "1" -> {
                        System.out.print("Tip: ");
                        String tip = scanner.nextLine();
                        System.out.print("Preț: ");
                        double pret = Double.parseDouble(scanner.nextLine());
                        service.categorieRepo.adaugaCategorie(new Categorie(0, tip, pret));
                    }
                    case "2" -> {
                        System.out.print("Nume locație: ");
                        String nume = scanner.nextLine();
                        System.out.print("Adresă: ");
                        String adresa = scanner.nextLine();
                        service.locatieRepo.adaugaLocatie(new Locatie(0, nume, adresa));
                    }
                    case "3" -> {
                        System.out.print("Nume eveniment: ");
                        String nume = scanner.nextLine();
                        System.out.print("ID categorie: ");
                        int cat = Integer.parseInt(scanner.nextLine());
                        if (service.categorieRepo.getCategorii().stream().noneMatch(c -> c.getId() == cat)) {
                            System.out.println("Categoria nu există.");
                            break;
                        }
                        System.out.print("ID locație: ");
                        int loc = Integer.parseInt(scanner.nextLine());
                        if (service.locatieRepo.getLocatii().stream().noneMatch(l -> l.getId() == loc)) {
                            System.out.println("Locația nu există.");
                            break;
                        }
                        System.out.print("Dată (YYYY-MM-DD): ");
                        LocalDate data = LocalDate.parse(scanner.nextLine());
                        service.evenimentRepo.adaugaEveniment(new Eveniment(0, nume, cat, loc, data));
                        System.out.println("Eveniment adăugat.");
                    }
                    case "4" -> afiseazaLista("categorii", service.categorieRepo.getCategorii());
                    case "5" -> afiseazaLista("locații", service.locatieRepo.getLocatii());
                    case "6" -> afiseazaLista("utilizatori", service.utilizatorRepo.getUtilizatori());
                    case "7" -> afiseazaLista("clienți", service.clientRepo.getClienti());
                    case "8" -> afiseazaLista("evenimente", service.evenimentRepo.getEvenimente());
                    case "9" -> {
                        System.out.print("ID eveniment de șters: ");
                        int id = Integer.parseInt(scanner.nextLine());
                        if (service.evenimentRepo.getEvenimente().stream().noneMatch(e -> e.getId() == id)) {
                            System.out.println("Evenimentul nu există.");
                            break;
                        }
                        service.stergeEveniment(id);
                    }
                    case "10" -> {
                        System.out.print("ID eveniment de editat: ");
                        int id = Integer.parseInt(scanner.nextLine());
                        Eveniment existent = service.evenimentRepo.getEvenimente().stream()
                                .filter(e -> e.getId() == id).findFirst().orElse(null);
                        if (existent == null) {
                            System.out.println("Evenimentul nu există.");
                            break;
                        }
                        System.out.print("Nume nou (" + existent.getNume() + "): ");
                        String nume = scanner.nextLine();
                        if (nume.isBlank()) nume = existent.getNume();
                        System.out.print("ID categorie (" + existent.getCodCategorie() + "): ");
                        String catStr = scanner.nextLine();
                        int codCat = catStr.isBlank() ? existent.getCodCategorie() : Integer.parseInt(catStr);
                        if (service.categorieRepo.getCategorii().stream().noneMatch(c -> c.getId() == codCat)) {
                            System.out.println("Categoria nu există.");
                            break;
                        }
                        System.out.print("ID locație (" + existent.getCodLocatie() + "): ");
                        String locStr = scanner.nextLine();
                        int codLoc = locStr.isBlank() ? existent.getCodLocatie() : Integer.parseInt(locStr);
                        if (service.locatieRepo.getLocatii().stream().noneMatch(l -> l.getId() == codLoc)) {
                            System.out.println("Locația nu există.");
                            break;
                        }
                        System.out.print("Dată nouă (" + existent.getData() + "): ");
                        String dataStr = scanner.nextLine();
                        LocalDate data = dataStr.isBlank() ? existent.getData() : LocalDate.parse(dataStr);
                        service.editeazaEveniment(new Eveniment(id, nume, codCat, codLoc, data));
                    }
                    case "0" -> {
                        clientLogat = null;
                        System.out.println("Delogat.");
                    }
                    default -> System.out.println("Opțiune invalidă.");
                }
            }
        }
    }

    public static <T> void afiseazaLista(String descriere, List<T> lista) {
        if (lista.isEmpty()) {
            System.out.println("Nu există " + descriere + " înregistrate.");
        } else {
            lista.forEach(System.out::println);
        }
    }
}
